package com.thinksys.activiti.bean;

import java.util.Date;


public class ClaimNotice {

	private String id;
	private String policyNumber;
	private Date date;
	private String nameOfInsured;
	private LossDetails lossDetails;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getNameOfInsured() {
		return nameOfInsured;
	}
	public void setNameOfInsured(String nameOfInsured) {
		this.nameOfInsured = nameOfInsured;
	}
	public LossDetails getLossDetails() {
		return lossDetails;
	}
	public void setLossDetails(LossDetails lossDetails) {
		this.lossDetails = lossDetails;
	}
}
