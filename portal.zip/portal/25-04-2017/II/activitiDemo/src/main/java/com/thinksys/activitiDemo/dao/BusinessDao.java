package com.thinksys.activitiDemo.dao;

public interface BusinessDao {

}
