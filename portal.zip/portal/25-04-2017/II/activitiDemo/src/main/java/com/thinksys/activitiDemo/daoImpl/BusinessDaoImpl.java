package com.thinksys.activitiDemo.daoImpl;

import org.springframework.stereotype.Repository;

@Repository
public class BusinessDaoImpl {

}
