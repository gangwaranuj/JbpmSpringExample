package com.thinksys.activitiDemo.bean;

public class ProcessCompleteBean {

	String status;
	String reason;
	public ProcessCompleteBean(String string) {
		// TODO Auto-generated constructor stub
		this.setStatus(string);
	}
	public ProcessCompleteBean(String string, String string2) {
		// TODO Auto-generated constructor stub
		this.setStatus(string);
		this.setReason(string2);
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
}
