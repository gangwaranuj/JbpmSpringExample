package com.thinksys.bpm.daoImpl;

import org.springframework.stereotype.Repository;

@Repository
public class BusinessDaoImpl {

}
