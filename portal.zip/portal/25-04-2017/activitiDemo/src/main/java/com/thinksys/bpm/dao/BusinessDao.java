package com.thinksys.bpm.dao;

public interface BusinessDao {

}
