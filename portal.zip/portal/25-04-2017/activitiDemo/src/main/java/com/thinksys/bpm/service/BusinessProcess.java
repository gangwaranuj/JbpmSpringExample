package com.thinksys.bpm.service;

import org.activiti.engine.task.Task;

import com.thinksys.bpm.bean.ProcessBean;
import com.thinksys.bpm.bean.ProcessCompleteBean;
import com.thinksys.bpm.bean.TaskBean;
import com.thinksys.bpm.utility.JsonResponse;

public interface BusinessProcess {


	public void checkUnfinishedExecution(); 

	public void assignTask(String instantID, String assigneeName);

	public void createUser(String name);

	public void authUser(String name);

	public void checkStatus(String id) ;

	public void complete(String id) ;

	public JsonResponse<ProcessCompleteBean> complete (String instantID ,String name);

	public JsonResponse<ProcessBean> start(ProcessBean processObject);

	JsonResponse<TaskBean> checkAssignTask(String assigneeName);

}
