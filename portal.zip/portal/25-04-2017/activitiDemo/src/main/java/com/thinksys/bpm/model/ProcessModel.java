package com.thinksys.bpm.model;

public class ProcessModel {

}
