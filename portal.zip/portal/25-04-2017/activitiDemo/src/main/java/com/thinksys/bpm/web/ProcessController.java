package com.thinksys.bpm.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.thinksys.bpm.bean.ProcessBean;
import com.thinksys.bpm.bean.ProcessCompleteBean;
import com.thinksys.bpm.bean.TaskBean;
import com.thinksys.bpm.service.BusinessProcess;
import com.thinksys.bpm.utility.JsonResponse;

/**
 * Handles requests for the application home page.
 */
@RestController
public class ProcessController {

	@Autowired
	BusinessProcess businessProcess;

	private static final Logger logger = LoggerFactory.getLogger(ProcessController.class);


	@RequestMapping(value = "/startProcess", method = RequestMethod.POST)
	public JsonResponse<ProcessBean> startHireProcess(@RequestBody String requestJson) {

		Gson gson =new Gson();
		ProcessBean processBean = gson.fromJson(requestJson,ProcessBean.class);
		JsonResponse<ProcessBean> response= businessProcess.start(processBean);
		return response;		          

	}

	@RequestMapping(value = "/addUser/{user}", method = RequestMethod.GET)
	
	public void addUser(@PathVariable String user) {

		businessProcess.createUser(user);
	}
	
	@RequestMapping(value = "/dashboard/{user}", method = RequestMethod.GET )
	public JsonResponse<TaskBean> dashboard(@PathVariable String user) {

		JsonResponse<TaskBean> response=businessProcess.checkAssignTask(user);
		return response;

	}

	@RequestMapping(value = "/completeTask/{processId}", method = RequestMethod.GET)

	public JsonResponse<ProcessCompleteBean> completeTask(@PathVariable int processId) {

		JsonResponse<ProcessCompleteBean>response= businessProcess.complete(""+processId, "employee");
		return response;

	}

}
