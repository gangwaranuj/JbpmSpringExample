package com.thinksys.activiti.serviceImpl;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;

import com.thinksys.activiti.bean.LoanApplicant;

public class Test  implements JavaDelegate{

	@Override
	public void execute(DelegateExecution arg0) throws Exception {
System.out.println("in test ....");

BusinessProcessImpl business= new BusinessProcessImpl();
//business.assignTask(id, );

	}
	
}
