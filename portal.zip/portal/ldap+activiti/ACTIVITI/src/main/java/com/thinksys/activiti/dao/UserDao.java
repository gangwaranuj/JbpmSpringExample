package com.thinksys.activiti.dao;

public interface UserDao {

	
}
