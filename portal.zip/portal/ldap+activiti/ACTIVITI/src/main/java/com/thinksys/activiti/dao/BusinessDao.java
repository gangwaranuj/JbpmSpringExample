package com.thinksys.activiti.dao;

import com.thinksys.activiti.utility.Response;

public interface BusinessDao {

	
	public Response checkSalary(String usrname);
	
}
 