package com.thinksys.activiti.serviceImpl;


import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;

import com.thinksys.activiti.bean.LoanApplicant;

public class LoanServiceImpl implements JavaDelegate
{
	
	@Override
	public void execute(DelegateExecution arg0) throws Exception {

		LoanApplicant loan = (LoanApplicant) arg0.getVariable("loanapplicant");
		long salary =(Long) arg0.getVariable("salary");
		loan.setIncome(salary);
		arg0.setVariable("loanapplicant", loan);
	}
}
