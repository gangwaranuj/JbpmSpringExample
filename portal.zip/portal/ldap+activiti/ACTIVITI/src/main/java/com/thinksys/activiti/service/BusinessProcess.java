package com.thinksys.activiti.service;

import com.thinksys.activiti.bean.LoanApplicant;
import com.thinksys.activiti.bean.ProcessCompleteBean;
import com.thinksys.activiti.bean.TaskBean;
import com.thinksys.activiti.model.EmpDetail;
import com.thinksys.activiti.utility.JsonResponse;

public interface BusinessProcess {

	public void assignTask(String instantID, String assigneeName);

	public void setCadidateUser(String processID);
	
	public boolean findTaskId(String taskID);

	public void checkUnfinishedExecution(); 

	public void createUser(String name);

	public void checkStatus(String id) ;

	public void authUser(String name);

	public void complete(String id) ;

	public JsonResponse<ProcessCompleteBean> complete (String instantID ,String name);

	public JsonResponse<LoanApplicant> start(LoanApplicant loanApplicant);

	public JsonResponse<TaskBean> checkAssignTask(String assigneeName);
	
	public JsonResponse<EmpDetail> findUserDetail(String username);


}
