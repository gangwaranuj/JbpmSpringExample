package com.thinksys.activiti.service;

public interface LoanService {

}
