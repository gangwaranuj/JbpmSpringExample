package com.thinksys.activiti.daoImpl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.thinksys.activiti.dao.BusinessDao;
import com.thinksys.activiti.model.EmpDetail;
import com.thinksys.activiti.util.Response;


@Repository
public class BusinessDaoImpl  implements BusinessDao{


	@Autowired
	HibernateTemplate hibernateTemplate;
	


	


	public Response checkSalary(String username){

		Response response= new Response();
		DetachedCriteria criteria = DetachedCriteria.forClass(EmpDetail.class);
		criteria.add(Restrictions.eq("name", username));
		List<EmpDetail> listUser = (List<EmpDetail>) this.hibernateTemplate.findByCriteria(criteria);	
		if(listUser.size()>0){
			response.setStatus(true);
			response.setData(listUser);
		}
		else{
			response.setStatus(false);
		}
		return response;							
	}

}
