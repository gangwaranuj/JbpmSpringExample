package com.thinksys.bpm.service;

import com.thinksys.bpm.bean.ProcessBean;
import com.thinksys.bpm.utility.JsonResponse;

public interface BusinessProcess {
	
	 
	public void checkUnfinishedExecution(); 
	 
	 public void assignTask(String instantID, String assigneeName);
	 
	 public void createUser(String name);
	 
	 public void checkAssignTask(String instantID);
	 
	 public void authUser(String name);
	 
	public void checkStatus(String id) ;
	 
	public void complete(String id) ;
	 
	 public void complete (String instantID ,String name);
	
	 public JsonResponse<ProcessBean> start(ProcessBean processObject);

}
