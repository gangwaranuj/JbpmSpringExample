package com.thinksys.bpm.serviceImpl;

import org.activiti.engine.IdentityService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.runtime.ProcessInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thinksys.bpm.bean.ProcessBean;
import com.thinksys.bpm.service.BusinessProcess;
import com.thinksys.bpm.utility.JsonResponse;

@Service
public class BusinessProcessImpl implements BusinessProcess
{
	 
	@Autowired
	 RepositoryService repositoryService;
	 
	@Autowired
	 RuntimeService runtimeService;
	 
	@Autowired
	 TaskService taskService;
	 
	@Autowired
	 IdentityService identityService;
	
	@Override
	public void checkUnfinishedExecution() {
		// TODO Auto-generated method stub
		for (ProcessInstance temp : runtimeService.createProcessInstanceQuery()
				 
				.list()) {
				 
				System.out.println(temp.getId());
				 
				}
	}

	@Override
	public void assignTask(String instantID, String assigneeName) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void createUser(String name) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void checkAssignTask(String instantID) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void authUser(String name) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void checkStatus(String id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void complete(String id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void complete(String instantID, String name) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public JsonResponse<ProcessBean> start(ProcessBean processBean ) {
		// TODO Auto-generated method stub
		JsonResponse<ProcessBean> response=new JsonResponse<ProcessBean>();
		if (repositoryService != null) {
			 System.out.println("Running");
			 String id = runtimeService.startProcessInstanceByKey("myProcess")
			 .getProcessInstanceId();
			processBean.setProcessId(id);
			response.setRecord(processBean);
			 }
		return response;
		
	}

}
