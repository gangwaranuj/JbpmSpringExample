package com.thinksys.bpm.controller;

import java.text.DateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

import org.activiti.engine.IdentityService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.DeploymentBuilder;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.thinksys.bpm.bean.ProcessBean;
import com.thinksys.bpm.bean.ProcessCompleteBean;
import com.thinksys.bpm.bean.TaskBean;
import com.thinksys.bpm.service.BusinessProcess;
import com.thinksys.bpm.utility.JsonResponse;

/**
 * Handles requests for the application home page.
 */
@RestController
public class HomeController {
	
	@Autowired
	BusinessProcess businessProcess;

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		  // deploy processes as one deployment
		/*  DeploymentBuilder deploymentBuilder = repositoryService.createDeployment();
		  deploymentBuilder.addClasspathResource("/Process.bpnm20.xml");
		  // deploy the processes
		  Deployment deployment = deploymentBuilder.deploy();
		  // retreive the processDefinitionId for this process
*/		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	   @ResponseStatus(value = HttpStatus.OK)
	    @RequestMapping(value = "/startProcess", method = RequestMethod.POST,
	            produces = MediaType.APPLICATION_JSON_VALUE)
	    public JsonResponse<ProcessBean> startHireProcess(@RequestBody ProcessBean processObject) {

		  JsonResponse<ProcessBean> response= businessProcess.start(processObject);
		  return response;		          
	        
	    }
	
	   @ResponseStatus(value = HttpStatus.OK)
	    @RequestMapping(value = "/addUser/{user}", method = RequestMethod.GET,
	            produces = MediaType.APPLICATION_JSON_VALUE)
	    public void addUser(@PathVariable String user) {

		businessProcess.createUser(user);
	        
	    }
	   
	   @ResponseStatus(value = HttpStatus.OK)
	    @RequestMapping(value = "/dashboard/{user}", method = RequestMethod.GET,
	            produces = MediaType.APPLICATION_JSON_VALUE)
	    public JsonResponse<TaskBean> dashboard(@PathVariable String user) {

		JsonResponse<TaskBean> response=businessProcess.checkAssignTask(user);
		return response;
	        
	    }
	   
	   @ResponseStatus(value = HttpStatus.OK)
	    @RequestMapping(value = "/completeTask/{processId}", method = RequestMethod.GET,
	            produces = MediaType.APPLICATION_JSON_VALUE)
	    public JsonResponse<ProcessCompleteBean> completeTask(@PathVariable int processId) {

		JsonResponse<ProcessCompleteBean>response= businessProcess.complete(""+processId, "employee");
		return response;
	        
	    }
	   
}
