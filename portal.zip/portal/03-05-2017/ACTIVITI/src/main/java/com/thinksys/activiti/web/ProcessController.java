package com.thinksys.activiti.web;

import org.activiti.engine.RuntimeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.thinksys.activiti.bean.LoanApplicant;
import com.thinksys.activiti.bean.ProcessCompleteBean;
import com.thinksys.activiti.bean.TaskBean;
import com.thinksys.activiti.service.BusinessProcess;
import com.thinksys.activiti.utility.JsonResponse;

/**
 * Handles requests for the application home page.
 */
@RestController
public class ProcessController {

	@Autowired
	RuntimeService runtimeService;
	
	
	@Autowired
	BusinessProcess businessProcess;

//	private static final Logger logger = LoggerFactory.getLogger(ProcessController.class);


	@RequestMapping(value = "/startProcess", method = RequestMethod.POST)
	public JsonResponse<LoanApplicant> startHireProcess(@RequestBody String requestJson) {

		Gson gson =new Gson();
		LoanApplicant loanApplicant = gson.fromJson(requestJson,LoanApplicant.class);
		JsonResponse<LoanApplicant> response= businessProcess.start(loanApplicant);
		return response;		          

	}

	@RequestMapping(value = "/addUser/{user}", method = RequestMethod.GET)
	
	public void addUser(@PathVariable String user) {

		businessProcess.createUser(user);
	}
	
	@RequestMapping(value = "/dashboard/{user}", method = RequestMethod.GET )
	public JsonResponse<TaskBean> dashboard(@PathVariable String user) {

		JsonResponse<TaskBean> response=businessProcess.checkAssignTask(user);
		return response;

	}

	@RequestMapping(value = "/completeTask/{processId}", method = RequestMethod.GET)

	public JsonResponse<ProcessCompleteBean> completeTask(@PathVariable int processId) {

		JsonResponse<ProcessCompleteBean>response= businessProcess.complete(""+processId, "employee");
		return response;

	}

}
