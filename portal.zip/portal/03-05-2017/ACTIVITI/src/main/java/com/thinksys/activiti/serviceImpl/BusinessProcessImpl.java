package com.thinksys.activiti.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.activiti.engine.IdentityService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.identity.User;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.activiti.engine.task.TaskQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thinksys.activiti.bean.LoanApplicant;
import com.thinksys.activiti.bean.ProcessCompleteBean;
import com.thinksys.activiti.bean.TaskBean;
import com.thinksys.activiti.dao.BusinessDao;
import com.thinksys.activiti.model.EmpDetail;
import com.thinksys.activiti.service.BusinessProcess;
import com.thinksys.activiti.utility.JsonResponse;
import com.thinksys.activiti.utility.Response;

@Service
public class BusinessProcessImpl implements BusinessProcess
{

	@Autowired
	BusinessDao businessDao;


	@Autowired
	RepositoryService repositoryService;

	@Autowired
	RuntimeService runtimeService;

	@Autowired
	TaskService taskService;

	@Autowired
	IdentityService identityService;

	@Override
	public void checkUnfinishedExecution() {
		// TODO Auto-generated method stub
		for (ProcessInstance temp : runtimeService.createProcessInstanceQuery()			 
				.list()) {

			System.out.println(temp.getId());

		}
	}

	@Override
	public void assignTask(String instantID, String assigneeName) {
		// TODO Auto-generated method stub
		TaskQuery task=taskService.createTaskQuery().processInstanceId(instantID);
		for(Task taskk:task.list())
		{
			taskk.setAssignee(assigneeName);
			taskService.saveTask(taskk);
		}
	}
	@Override
	public void setCadidateUser(String processID)
	{
		List<Task> task=taskService.createTaskQuery().processInstanceId(processID).list();
		for(Task tasks:task)
		{
			taskService.addCandidateUser(tasks.getId(), "Employee");
			taskService.addCandidateUser(tasks.getId(), "manager");						
			taskService.saveTask(tasks);
		}

	}
	@Override
	public void createUser(String name) {
		// TODO Auto-generated method stub
		User user = identityService.newUser(name);
		identityService.saveUser(user);
		System.out.println(user.getId()+" -->"+" has been created");
	}

	@Override
	public JsonResponse<TaskBean> checkAssignTask(String assigneeName) {

		JsonResponse<TaskBean> response = new JsonResponse<TaskBean>();
		TaskQuery taskQuery =  taskService.createTaskQuery().active();
		List <TaskBean>record = new ArrayList<TaskBean>();
		for(Task task : taskQuery.list())
		{
			if(task.getAssignee()!=null && task.getAssignee().equalsIgnoreCase(assigneeName))
			{
				record.add(new TaskBean(task.getAssignee(),task.getCreateTime(),task.getDescription(),task.getDueDate(),task.getPriority(),task.getOwner(),task.getId(),task.getName(),this.runtimeService.getVariables(task.getExecutionId())));
			}
		}
		response.setRecords(record);
		return response;
	}

	@Override
	public void authUser(String name) {
	}

	@Override
	public void checkStatus(String id) {
	}

	@Override
	public void complete(String id) {

		System.out.println("in complete");
		TaskQuery task=taskService.createTaskQuery().processInstanceId(id);
		for(Task taskk:task.list())
		{
			taskService.complete(taskk.getId());
		}
	}

	@Override
	public JsonResponse<ProcessCompleteBean> complete(String instantID, String name) {
		// TODO Auto-generated method stub
		TaskQuery task=taskService.createTaskQuery().active();
		JsonResponse<ProcessCompleteBean>response= new JsonResponse<ProcessCompleteBean>();
		System.out.println(task.list());
		List <ProcessCompleteBean>record= new ArrayList<ProcessCompleteBean>();
		boolean flag=findTaskId(instantID);

		if(flag==true){
			for(Task taskk:task.list())
			{
				if(taskk.getId().equalsIgnoreCase(instantID))
				{
					Map<String,Object> variable=this.runtimeService.getVariables(taskk.getExecutionId());
					int amount=(Integer) variable.get("Amount");
					if(amount<=100)
					{
						record.add(new ProcessCompleteBean(taskk.getId()+" Request ID has been approved"));
						response.setMessage("Request approved");
						taskService.complete(taskk.getId());
					}
					else
					{
						record.add(new ProcessCompleteBean(taskk.getId()+" Request ID has been declined","Request Amount was greater than 100 rs"));
						response.setMessage("Request Rejected");
						taskService.complete(taskk.getId());
					}
				}
			}
		}
		else{
			record.add(new ProcessCompleteBean(instantID+" invalid task id."));
			response.setMessage("Request Rejected");
		}
		response.setRecords(record);
		return response;
	}

	@Override
	public boolean findTaskId(String taskID){

		TaskQuery task=taskService.createTaskQuery().active();
		for(Task taskk:task.list()){
			if(taskk.getId().equalsIgnoreCase(taskID)){
				return true;
			}
		}

		return false;
	}

	@Override
	public JsonResponse<LoanApplicant> start (LoanApplicant loanApplicant) {

		JsonResponse<LoanApplicant> response=new JsonResponse<LoanApplicant>();
		if (repositoryService != null) {
			System.out.println("Running");
			//			Map<String,Object> map = new HashMap<String,Object >();
			//			map.put("name", loanApplicant.getName());
			//			map.put("income", loanApplicant.getIncome());
			//			map.put("loanAmount",loanApplicant.getLoanAmount());

			/******************drploy the files we need****************/
			repositoryService
			.createDeployment()
			.addClasspathResource("workFlowExample.bpmn")
			.addClasspathResource("Sample.drl")
			.deploy();

			/**********!*************/
			String id = runtimeService.startProcessInstanceByKey("com.javacodegeeks.drools").getProcessDefinitionId();
		
			this.complete(id);
			findUserDetail("anuj");

			this.assignTask(id, "manager");
			response.setMessage("Loan request has been raised successfully.");
			response.setResult("Ok");
			response.setRecord(loanApplicant);
		}
		return response;
	}

	@Override
	public JsonResponse<EmpDetail> findUserDetail(String username) {

		JsonResponse<EmpDetail> jsonResponse =null;

		Response response = this.businessDao.checkSalary(username);
		if(response.getStatus()){
			List<EmpDetail> results = (List<EmpDetail>) response.getData();
			List<EmpDetail> list = new ArrayList<EmpDetail>();
			for(EmpDetail empdetails: results){
				list.add(empdetails);
				System.out.println("name:"+empdetails.getName()+"salary:"+empdetails.getSalary());
				return jsonResponse;
			}
		}
		return jsonResponse;
	}
}
