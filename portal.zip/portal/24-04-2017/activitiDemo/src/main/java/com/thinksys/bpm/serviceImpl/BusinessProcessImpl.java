package com.thinksys.bpm.serviceImpl;

import org.activiti.engine.IdentityService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.identity.User;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thinksys.bpm.bean.ProcessBean;
import com.thinksys.bpm.service.BusinessProcess;
import com.thinksys.bpm.utility.JsonResponse;

@Service
public class BusinessProcessImpl implements BusinessProcess
{
	
	private  final Logger logger = LoggerFactory.getLogger(BusinessProcessImpl.class);


	@Autowired
	RepositoryService repositoryService;

	@Autowired
	RuntimeService runtimeService;

	@Autowired
	TaskService taskService;

	@Autowired
	IdentityService identityService;

	@Override
	public void checkUnfinishedExecution() {

		for (ProcessInstance temp : runtimeService.createProcessInstanceQuery()
				.list()) {
			System.out.println(temp.getId());

		}
	}

	@Override
	public void assignTask(String instantID, String assigneeName) {

		Task task = taskService.createTaskQuery().processInstanceId(instantID).singleResult();

		task.setAssignee(assigneeName);
		taskService.saveTask(task);
	}

	@Override
	public JsonResponse<String> createUser(String name) {

		JsonResponse<String> jsonResponse=new JsonResponse<String>();
		User user = identityService.newUser(name);
		identityService.saveUser(user);
		jsonResponse.setMessage(user.getId()+" -->"+" has been created");
		this.logger.info("BusinessProcessImpl :: "+user.getId()+" -->"+" has been created");
		return jsonResponse;

	}

	@Override
	public void checkAssignTask(String instantID) {

		Task task =  taskService.createTaskQuery().processInstanceId(instantID).singleResult();
		System.out.println(task.getName() + " assined To : "+task.getAssignee());

	}

	@Override
	public void authUser(String name) {

		identityService.setAuthenticatedUserId(name);

	}

	@Override
	public void checkStatus(String id) {

		Task temp = taskService.createTaskQuery().processInstanceId(id)
				.singleResult();
		System.out.println(temp.getName() + " -> " + temp.getId());

	}

	@Override
	public JsonResponse<String> complete(String id) {


		JsonResponse<String> response=new JsonResponse<String>();
		taskService.complete(id);
		response.setMessage("Task Completed..");
		return response;

	}

	@Override
	public void complete(String instantID, String name) {


		//Task temp = taskService.createTaskQuery().processInstanceId(instantID).singleResult().taskAssignee(name).singleResult();
		Task task=taskService.createTaskQuery().processInstanceId(instantID).singleResult();
		taskService.complete(task.getId());


	}

	@Override
	public JsonResponse<ProcessBean> start(ProcessBean processBean ) {


		JsonResponse<ProcessBean> response=new JsonResponse<ProcessBean>();
		if (repositoryService != null) {
			System.out.println("Running");
			String id = runtimeService.startProcessInstanceByKey("myrefundProcess").getId();
			processBean.setProcessId(id);
			response.setRecord(processBean);
		}
		return response;
		//		 ProcessEngine processEngine = ProcessEngines.getDefaultProcessEngine();
		//	        RepositoryService repositoryService = processEngine.getRepositoryService();
		/*
	        DeploymentBuilder builder = repositoryService.createDeployment();
	        builder.addClasspathResource("refundProcess.bpmn20.xml");
	        builder.deploy();
		 */
		/* List<ProcessDefinition> p = repositoryService.createProcessDefinitionQuery().list();
	        for(int i=0;i<p.size();i++){
	            System.out.println(p.get(i).getKey());
	        }
	        runtimeService.startProcessInstanceByKey("myrefundProcess");
	        System.out.println("ok......");*/
	}

}
