package com.thinksys.bpm.bean;

public class ProcessBean {

	public String emplName;
	public int noofDays;
	public int priority;
	public String processId;
	public String getProcessId() {
		return processId;
	}
	public void setProcessId(String id) {
		this.processId = id;
	}
	public String getEmplName() {
		return emplName;
	}
	public void setEmplName(String emplName) {
		this.emplName = emplName;
	}
	public int getNoofDays() {
		return noofDays;
	}
	public void setNoofDays(int noofDays) {
		this.noofDays = noofDays;
	}
	@Override
	public String toString() {
		return "ProcessBean [emplName=" + emplName + ", noofDays=" + noofDays + ", priority=" + priority + "]";
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	
}
