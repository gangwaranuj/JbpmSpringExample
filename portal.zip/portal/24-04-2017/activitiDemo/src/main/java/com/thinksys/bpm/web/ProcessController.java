package com.thinksys.bpm.web;

import java.text.DateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

import org.activiti.engine.runtime.ProcessInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.thinksys.bpm.bean.ProcessBean;
import com.thinksys.bpm.service.BusinessProcess;
import com.thinksys.bpm.utility.JsonResponse;

/**
 * Handles requests for the application home page.
 */
@RestController
public class ProcessController {
	
	private static final Logger logger = LoggerFactory.getLogger(ProcessController.class);
	
	@Autowired
	BusinessProcess businessProcess;
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	
	
	   @ResponseStatus(value = HttpStatus.OK)
	    @RequestMapping(value = "/startProcess", method = RequestMethod.POST,
	            produces = MediaType.APPLICATION_JSON_VALUE)
	    public JsonResponse<ProcessBean> startHireProcess(@ModelAttribute ProcessBean processObject) {

		  JsonResponse<ProcessBean> response= businessProcess.start(processObject);
		  return response;		          
	        
	    }
	   @ResponseStatus(value = HttpStatus.OK)
	    @RequestMapping(value = "/complete/{task_id}", method = RequestMethod.GET,
	            produces = MediaType.APPLICATION_JSON_VALUE)
	    public JsonResponse<String> completeTaskById(@PathVariable String task_id) {

		  JsonResponse<String> response= businessProcess.complete(task_id);
		  return response;		          
	        
	    }
	   
	   @ResponseStatus(value = HttpStatus.OK)
	   @RequestMapping(value = "createUser/{username}" ,method =RequestMethod.GET)
	   public JsonResponse<String> createUser(@PathVariable String username){
		   
		   JsonResponse<String> response= businessProcess.createUser(username);
		   return response;
		   
		   
	   }
	   
	
}
