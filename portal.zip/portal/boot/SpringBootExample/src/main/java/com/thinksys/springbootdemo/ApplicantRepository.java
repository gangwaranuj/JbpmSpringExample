package com.thinksys.springbootdemo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ApplicantRepository extends JpaRepository<Applicantbean, Long> {

}