/**
 * 
 */


function service(_render, _url, _data) {
	var _request = new XMLHttpRequest();
	_request.onreadystatechange = function(_response) {
		if (_request.readyState === 4) {
			if (_request.status === 200) {
				responseText = this.responseText;
				responseData = JSON.parse(this.responseText);
				if (typeof _render === "function")
					_render()
			}
		}
	};
	if (_data) {
		_request.open('POST', _url, false);
		_request.send(_data);
	} else {
		_request.open('GET', _url, false);
		_request.send();
	}
};
