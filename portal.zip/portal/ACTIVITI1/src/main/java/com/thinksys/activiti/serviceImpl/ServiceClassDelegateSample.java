package com.thinksys.activiti.serviceImpl;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;

public class ServiceClassDelegateSample implements JavaDelegate {

	
	/*RuntimeService runtimeService1;  
	

	public RuntimeService getRuntimeService1() {
		return runtimeService1;
	}

	public void setRuntimeService1(RuntimeService runtimeService1) {
		this.runtimeService1 = runtimeService1;
	}*/

	@Override
	public void execute(DelegateExecution delegateExecution) throws Exception {

		System.out.println("in service task class.");
		System.out.println("Executed process with key "+delegateExecution.getProcessBusinessKey()+" with process definition Id "+delegateExecution.getProcessDefinitionId()+" with process instance Id "+delegateExecution.getProcessInstanceId()+" and current task name is "+delegateExecution.getCurrentActivityName());
		
	/*	System.out.println(runtimeService1);
		runtimeService1.setVariable(delegateExecution.getProcessDefinitionId(), "employee", "anuj");
		runtimeService1.setVariable(delegateExecution.getProcessDefinitionId(), "employeeManager", "gautum.sachin@thinksys.com");
		runtimeService1.setVariable(delegateExecution.getProcessDefinitionId(), "days", "5");
	*/
	}

}
