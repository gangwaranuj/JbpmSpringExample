package com.thinksys.activiti.dao;

public interface BusinessDao {

}
