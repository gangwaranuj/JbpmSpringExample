package com.thinksys.activiti.service;

import com.thinksys.activiti.bean.ProcessBean;
import com.thinksys.activiti.bean.ProcessCompleteBean;
import com.thinksys.activiti.bean.TaskBean;
import com.thinksys.activiti.utility.JsonResponse;

public interface BusinessProcess {

	public void setCadidateUser(String processID);
	
	public void checkUnfinishedExecution(); 

	public void assignTask(String instantID, String assigneeName);

	public void createUser(String name);

	public void authUser(String name);

	public void checkStatus(String id) ;

	public void complete(String id) ;

	public JsonResponse<ProcessCompleteBean> complete (String instantID ,String name);

	public JsonResponse<ProcessBean> start(ProcessBean processObject);

	public JsonResponse<TaskBean> checkAssignTask(String assigneeName);
	
	public boolean findTaskId(String taskID);

}
