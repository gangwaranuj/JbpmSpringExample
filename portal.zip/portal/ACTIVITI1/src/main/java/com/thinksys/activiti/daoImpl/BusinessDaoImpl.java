package com.thinksys.activiti.daoImpl;

import org.springframework.stereotype.Repository;

@Repository
public class BusinessDaoImpl {

}
