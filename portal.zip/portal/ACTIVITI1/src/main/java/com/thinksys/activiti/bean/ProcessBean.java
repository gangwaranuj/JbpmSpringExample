package com.thinksys.activiti.bean;

public class ProcessBean {

	public String emplName;
	public int amount;
	public int priority;
	public String processId;
	public String getProcessId() {
		return processId;
	}
	public void setProcessId(String id) {
		this.processId = id;
	}
	public String getEmplName() {
		return emplName;
	}
	public void setEmplName(String emplName) {
		this.emplName = emplName;
	}
	public int getamount() {
		return amount;
	}
	public void setamount(int noofDays) {
		this.amount = noofDays;
	}
	@Override
	public String toString() {
		return "ProcessBean [emplName=" + emplName + ", noofDays=" + amount + ", priority=" + priority + "]";
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	
}
