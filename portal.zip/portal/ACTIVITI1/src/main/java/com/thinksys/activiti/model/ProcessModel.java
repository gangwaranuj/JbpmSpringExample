package com.thinksys.activiti.model;

public class ProcessModel {

}
